<?php 
define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PWD","mysql");
define("DB_DBNAME","ecommerce");
define("DB_CHARSET","utf8");
