<?php

// Start of mysqlnd v.mysqlnd 5.0.12-dev - 20150407 - $Id: d8daadaf41e3cd81d7c6ae96c6091fd15b2c9382 $
// End of mysqlnd v.mysqlnd 5.0.12-dev - 20150407 - $Id: d8daadaf41e3cd81d7c6ae96c6091fd15b2c9382 $
