<?php

// Start of amf v.0.9.2-dev

function amf_encode () {}

function amf_decode () {}

function amf_join_test () {}

function amf_sb_new () {}

function amf_sb_append () {}

function amf_sb_append_move () {}

function amf_sb_length () {}

function amf_sb_as_string () {}

function amf_sb_write () {}

function amf_sb_memusage () {}

function amf_sb_flat () {}

function amf_sb_echo () {}

// End of amf v.0.9.2-dev
