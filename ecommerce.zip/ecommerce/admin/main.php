<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
<center>
	<h3>System Message</h3>
	<table width="70%" border="1" cellpadding="5" cellspacing="0" bgcolor="#cccccc">
		<tr>
			<th>Operating System</th>
			<td><?php echo PHP_OS;?></td>
		</tr>
		<tr>
			<th>PHP Version</th>
			<td><?php echo PHP_VERSION;?></td>
		</tr>
		<tr>
			<th>Operation Mode</th>
			<td><?php echo PHP_SAPI;?></td>
		</tr>
	</table>
	<h3>Software Information</h3>
	<table width="70%" border="1" cellpadding="5" cellspacing="0" bgcolor="#cccccc">
		<tr>
			<th>System Name</th>
			<td>E-commerce Background Management System</td>
		</tr>
		
		
	</table>
</center>

</body>
</html>