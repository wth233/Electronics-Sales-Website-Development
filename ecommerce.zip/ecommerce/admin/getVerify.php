<?php 
require_once '../lib/image.func.php';
verifyImage();